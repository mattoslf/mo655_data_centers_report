#! /usr/bin/env python
import sys, parse, math

def main():

	fileIn = open(sys.argv[1], 'r')

	i = 0
	flow = {}
	texto = fileIn.read()
	throughput = [float(r.fixed[0]) for r in parse.findall("Vazao: {} Mbps\n", texto)]
	delay = [float(r.fixed[0]) for r in parse.findall("Atraso: {} ms\n", texto)]
	lostPckt = [float(r.fixed[0]) for r in parse.findall("Perda: {} % dos pacotes\n", texto)]

	avgTP = [sum(throughput)/len(throughput)] * len(throughput)
	temp = [(a-b)*(a-b) for a,b in zip(throughput, avgTP)]
	stddevTP = math.sqrt(sum(temp)/len(temp))

	minTP = avgTP[0] - 1.96*(stddevTP/math.sqrt(len(temp)))
	maxTP = avgTP[0] + 1.96*(stddevTP/math.sqrt(len(temp)))

	print(minTP, avgTP[0], maxTP)

	avgDe = [sum(delay)/len(delay)] * len(delay)
	temp = [(a-b)*(a-b) for a,b in zip(delay, avgDe)]
	stddevDe = math.sqrt(sum(temp)/len(temp))

	minDe = avgDe[0] - 1.96*(stddevDe/math.sqrt(len(temp)))
	maxDe = avgDe[0] + 1.96*(stddevDe/math.sqrt(len(temp)))

	print (minDe, avgDe[0], maxDe)

	avgLP = [sum(lostPckt)/len(lostPckt)] * len(lostPckt)
	temp = [(a-b)*(a-b) for a,b in zip(lostPckt, avgLP)]
	stddevLP = math.sqrt(sum(temp)/len(temp))

	minLP = avgLP[0] - 1.96*(stddevLP/math.sqrt(len(temp)))
	maxLP = avgLP[0] + 1.96*(stddevLP/math.sqrt(len(temp)))

	print(minLP, avgLP[0], maxLP)

#	print("Vazao: " + str(math.fsum(throughput)/len(throughput)) + " Mbps")
#	print("Atraso: " + str((math.fsum(delay)/len(delay))/(math.fsum(rvcPckt)/len(rvcPckt))) + " ms")
#	print("Perda: " + str(math.fsum(lostPckt)/len(lostPckt)) + " pacotes")

if  __name__ =='__main__':main()
