#! /usr/bin/env python
import os

values = [5, 10, 15, 20, 25, 30, 35, 40]
types = ["cbr", "rajada"]
protocols = ["udp", "tcp"]
moves = ["parado", "andando"]
iters = range(5)

mv = 1
for m in moves:
	ty = 0
	for t in types:
		ptc = 1
		for p in protocols:
			for i in iters:
				for v in values:
					print("Iter " + str(i) + " com " + str(v) + " clientes em " + t + " e " + p + " " + m + "!")
					os.popen('./waf --run=\"projeto --nStas=' + str(v) + ' --flowType=' + str(ty) + ' --protocolType=' + str(ptc) + ' --moveType=' + str(mv) + ' --RngRun=' + str(4*i) + '\" > results-' + m + '-' + p + '/projeto-' + t + '-' + p + '-' + str(v) + '-' + str(i) + '.out','w')
					os.popen('./parser.py results-' + m + '-' + p + '/projeto-' + t + '-' + p + '-' + str(v) + '-' + str(i) + '.out >> results-' + m + '-' + p + '/resume-' + t + '-' + p + '-' + str(v) + '.log','w')

			for v in values:
				os.popen('./parser2.py results-' + m + '-' + p + '/resume-' + t + '-' + p + '-' + str(v) + '.log > results-' + m + '-' + p + '/final-' + t + '-' + p + '-' + str(v) + '.log','w')

			ptc += 1
		ty += 1
	mv += 1
