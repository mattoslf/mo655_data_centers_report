#! /usr/bin/env python
import sys, parse, math

def main():

	fileIn = open(sys.argv[1], 'r')
	name = sys.argv[1].split('-')

	n = int(name[5])

	print(n)

	i = 0
	flow = {}
	texto = fileIn.read()
	protocol = texto.split('\n')[0].split(' ')[1]
	ips = [(r.fixed[1],r.fixed[2]) for r in parse.findall("Flow {} ({} -> {})", texto)]
	throughput = [float(r.fixed[0]) for r in parse.findall("Throughput: {} Mbps\n", texto)]
	delay = [float(r.fixed[0]) for r in parse.findall("Delay: +{}ns\n", texto)]
	rcvPckt = [int(r.fixed[0]) for r in parse.findall("Rx Packets: {}\n", texto)]
	sndPckt = [int(r.fixed[0]) for r in parse.findall("Tx Packets: {}\n", texto)]
	lostPckt = [int(r.fixed[0]) for r in parse.findall("Lost Packets: {}\n", texto)]

	if(protocol == 'TCP'):
		throughput1 = throughput[0:(n-1)]
		throughput2 = throughput[n:((2*n)-1)]
		throughput = [(x + y)/2 for x, y in zip(throughput1, throughput2)]

		delay1 = delay[0:(n-1)]
		delay2 = delay[n:((2*n)-1)]
		delay = [(x + y)/2 for x, y in zip(delay1, delay2)]

		lostPckt1 = lostPckt[0:(n-1)]
		lostPckt2 = lostPckt[n:((2*n)-1)]
		lostPckt = [(x + y)/2 for x, y in zip(lostPckt1, lostPckt2)]

		sndPckt1 = sndPckt[0:(n-1)]
		sndPckt2 = sndPckt[n:((2*n)-1)]
		sndPckt = [(x + y)/2 for x, y in zip(sndPckt1, sndPckt2)]

	print("Vazao: " + str(math.fsum(throughput)/len(throughput)) + " Mbps")
	print("Atraso: " + str(math.fsum(delay)/len(delay)) + " ms")
	print("Perda: " + str(100*math.fsum(lostPckt)/math.fsum(sndPckt)) + " % dos pacotes")

if  __name__ =='__main__':main()
